"""
Server package for MOOD.
"""
